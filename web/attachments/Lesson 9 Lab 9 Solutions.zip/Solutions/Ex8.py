"""Exercise 8"""

import string


def encrypt(message, key):
    encrypted_message = []
    alphabet = string.ascii_lowercase

    for char in message:
        if char.lower() in alphabet:
            if char.islower():
                encrypted_char = alphabet[(alphabet.index(char.lower()) + key) % 26]
            else:
                encrypted_char = alphabet[(alphabet.index(char.lower()) + key) % 26].upper()
            encrypted_message.append(encrypted_char)
        else:
            encrypted_message.append(char)

    return ''.join(encrypted_message)


def decrypt(ciphertext, key):
    decrypted_message = []
    alphabet = string.ascii_lowercase

    for char in ciphertext:
        if char.lower() in alphabet:
            if char.islower():
                decrypted_char = alphabet[(alphabet.index(char.lower()) - key) % 26]
            else:
                decrypted_char = alphabet[(alphabet.index(char.lower()) - key) % 26].upper()
            decrypted_message.append(decrypted_char)
        else:
            decrypted_message.append(char)

    return ''.join(decrypted_message)


# Example usage:

# Encryption with key 8
message1 = "'You can show black is white by argument,' said Filby, 'but you will never convince me.'"
key1 = 8
encrypted_message1 = encrypt(message1, key1)
print(f"Encrypted message 1.a: {encrypted_message1}")

# Encryption with key 21
message2 = "Besty is 45 years old"
key2 = 21
encrypted_message2 = encrypt(message2, key2)
print(f"Encrypted message 1.b: {encrypted_message2}")

# Decryption with key 2
ciphertext1 = "'Kv uqwpfu rncwukdng gpqwij.'"
key3 = 2
decrypted_message1 = decrypt(ciphertext1, key3)
print(f"Decrypted message 2.a: {decrypted_message1}")

# Decryption with key 22
ciphertext2 = "Xqp whh ahoa kb pda sknhz swo ejreoexha."
key4 = 22
decrypted_message2 = decrypt(ciphertext2, key4)
print(f"Decrypted message 2.b: {decrypted_message2}")

