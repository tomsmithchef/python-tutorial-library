"""Exercise 1"""

# test : West East South North
# # Solution
# strings = input("Enter three string seperate by space: ")
# user_list = strings.split()
#
# # convert each item to int type
# for i in range(len(user_list)):
#     print(f'Name{i + 1}: {user_list[i]}')

# Solution 2
strings = input("Enter three string seperate by space: ")
user_list = strings.split()
# get values from the list
for i,  user in  enumerate(user_list):
    print(f'Name{i+1}: {user}')