"""Exercise 4"""



# def multiplication_or_sum(num1, num2):
#     # calculate product of two number
#     product = num1 * num2
#     # check if product is less then 1000
#     if product <= 1000:
#         return product
#     else:
#         # product is greater than 1000 calculate sum
#         return num1 + num2


def multiplication_or_sum(num1, num2):
    try:
        # convert inputs to floats (assuming decimals are allowed)
        #num1 = float(num1)
        #num2 = float(num2)

        # calculate product of two numbers
        product = num1 * num2

        # check if product is less than or equal to 1000
        if product <= 1000:
            return product
        else:
            # product is greater than 1000, calculate sum
            return num1 + num2

    except ValueError:
        return "Error: Please enter valid numbers."
    except Exception as e:
        return f"An error occurred: {e}"

#
# # Example usage:
# result1 = multiplication_or_sum(20, 30)  # Output: 600
# print(result1)
#
# result2 = multiplication_or_sum(50, 60)  # Output: 110 (sum because product > 1000)
# print(result2)
#
# result3 = multiplication_or_sum("abc", 60)  # Output: Error: Please enter valid numbers.
# print(result3)
#
# result4 = multiplication_or_sum(1000, 50.2)  # Output: 50000
# print(result4)


# users inputs
number1 = float(input("Enter number 1: "))
number2 = float(input("Enter number 2: "))

# Calling te function
result = multiplication_or_sum(number1, number2)
print("The result is", result)

