"""Exercise 3"""

def working_with_string():
    # Input list of strings from the user
    input_strings = input('Enter a list of strings separated by spaces:')
    strings_list = input_strings.split()

    # Concatenate strings with '#' between them
    result_string = '_'.join(strings_list)

    # Print the result
    print(f"Resulting string: { result_string}")


working_with_string()