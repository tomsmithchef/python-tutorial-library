"""Exercise 6"""

def divide_numbers(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("Error: Division by zero!")
    except TypeError:
        print("Error: Invalid types for division!")
    else:
        return result

# Test cases
print(divide_numbers(0, 10))
print(divide_numbers(3.50, 2))
print(divide_numbers(11, 0))
print(divide_numbers(12, '4'))