

# Test: 10 65 59 30
input_string = input('Enter elements of a list separated by space :')

user_list = input_string.split()

# convert each item to int type
for i, user in enumerate(user_list):
    # convert each item to int type
    user_list[i] = int(user)

print('User list: ', user_list)
# Calculating the sum of list elements
print("The Sum is equal to: ", sum(user_list))