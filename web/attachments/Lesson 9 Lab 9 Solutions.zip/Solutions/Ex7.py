"""Exercise 7"""

def divide_numbers(a, b):
    try:
        result = a / b
    except (ZeroDivisionError, TypeError) as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"Unexpected error occurred: {e}")

    else:
        return result



# Test cases
print(divide_numbers(0, 10))
print(divide_numbers(3.50, 2))
print(divide_numbers(11, 0))
print(divide_numbers(12, '4'))