"""Exercise 5"""

import socket  # Importing the socket module

# Create a socket object using IPv4 and TCP protocol
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Use the connect_ex() method to check if the connection
# to port 80 on IP '142.112.28.74' succeeds
result = sock.connect_ex(('142.112.28.74', 46))

# Check the result of the connection attempt
if result == 0:
    print("Port is open")  # Print this message if the port is open
else:
    print("Port is not open")  # Print this message if the port is not open

# Close the socket connection
sock.close()
